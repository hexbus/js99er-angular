// VDP code for the TI-99/4A by Tursi
// and a little GROM code too since I need it for the
// character set copy.
// You can copy this file and use it at will ;)

// VDP access
#define VDPRD	*((volatile unsigned char*)0x8800)
#define VDPST	*((volatile unsigned char*)0x8802)
#define VDPWA	*((volatile unsigned char*)0x8C02)
#define VDPWD	*((volatile unsigned char*)0x8C00)

#define GROMWA	*((volatile unsigned char*)0x9c02)
#define GROMRD	*((volatile unsigned char*)0x9800)

// WARNING: Side-effects abound here, don't pass in parameters that increment or anything like that
// all parameters are used /at least/ twice.
#define VDP_SET_ADDRESS(x)			VDPWA=((x)&0xff); VDPWA=((x)>>8)
#define VDP_SET_ADDRESS_WRITE(x)	VDPWA=((x)&0xff); VDPWA=(((x)>>8)|0x40)
#define VDP_SET_REGISTER(r,v)		VDPWA=(v); VDPWA=(0x80|(r))

#define GROM_SET_ADDRESS(x)			GROMWA=((x)>>8); GROMWA=((x)&0xff);

// not valid for text mode
#define VDP_SCREEN_POS(r,c)		(((r)<<5)+(c))
// this one is (note it's slower and uses r twice)
#define VDP_SCREEN_TEXT(r,c)	(((r)<<5)+((r)<<3)+(c))

// the interrupt waits will conflict with each other, so you
// can only use one or the other, depending on whether you want
// the console interrupt code to run

// wait for a vblank (interrupts disabled - will work unreliably if enabled)
// call vdpwaitvint() if you want to keep running the console interrupt
#define VDP_WAIT_VBLANK  		while (!(VDPST & VDP_ST_INT)) { }

// TI ROM Interrupt hook (store your pointer here)
#define VDP_INT_HOOK			*((volatile void**)0x83C4)
#define VDP_INT_COUNTER			*((volatile unsigned char*)0x8379)

// we enable interrupts via the CPU instruction, not the VDP itself, because it's faster
// Note that on the TI interrupts DISABLED is the default state
#define VDP_INT_ENABLE	__asm__("LIMI 2")
#define VDP_INT_DISABLE	__asm__("LIMI 0")

// some register settings
#define VDP_ST_INT		0x80
#define VDP_ST_5SP		0x40
#define VDP_ST_COINC	0x20
#define VDP_ST_MASK		0x1f

#define VDP_REG_MODE0	0x00
#define VDP_REG_MODE1	0x01
#define VDP_REG_SIT		0x02
#define VDP_REG_CT		0x03
#define VDP_REG_PDT		0x04
#define VDP_REG_SAL		0x05
#define VDP_REG_SDT		0x06
#define VDP_REG_COL		0x07

#define VDP_MODE0_BITMAP		0x02
#define VDP_MODE0_EXTVID		0x01
#define VDP_MODE1_16K			0x80
#define VDP_MODE1_UNBLANK		0x40
#define VDP_MODE1_INT			0x20
#define VDP_MODE1_TEXT			0x10
#define VDP_MODE1_MULTI			0x08
#define VDP_MODE1_SPMODE16x16	0x02
#define VDP_MODE1_SPRMAG		0x01

#define VDP_SPR_8x8			0x00
#define	VDP_SPR_8x8MAG		(VDP_MODE1_SPRMAG)
#define VDP_SPR_16x16		(VDP_MODE1_SPRMODE16x16)
#define VDP_SPR_16x16MAG	(VDP_MODE1_SPRMODE16x16 | VDP_MODE1_SPRMAG)

#define COLOR_TRANS		0x00
#define COLOR_BLACK		0x01
#define COLOR_MEDGREEN	0x02
#define COLOR_LTGREEN	0x03
#define COLOR_DKBLUE	0x04
#define COLOR_LTBLUE	0x05
#define COLOR_DKRED		0x06
#define COLOR_CYAN		0x07
#define COLOR_MEDRED	0x08
#define COLOR_LTRED		0x09
#define COLOR_DKYELLOW	0x0A
#define COLOR_LTYELLOW	0x0B
#define COLOR_DKGREEN	0x0C
#define COLOR_MAGENTA	0x0D
#define COLOR_GRAY		0x0E
#define COLOR_WHITE		0x0F

int set_graphics(int sprite_mode);
int set_text();
int set_multicolor(int sprite_mode);
int set_bitmap(int sprite_mode);
void writestring(int row, int col, char *pStr);
void vdpmemset(int pAddr, int ch, int cnt);
void vdpmemcpy(int pAddr, const unsigned char *pSrc, int cnt);
void vdpmemread(int pAddr, unsigned char *pDest, int cnt);
void vdpwriteinc(int pAddr, int nStart, int cnt);
void vdpchar(int pAddr, int ch);
void vdpwritescreeninc(int pAddr, int nStart, int cnt);
void vdpscreenchar(int pAddr, int ch);
void vdpwaitvint();
void puts(char *s);
void scrn_scroll();
void hchar(int r, int c, int ch, int cnt);
void vchar(int r, int c, int ch, int cnt);
unsigned char gchar(int r, int c);
void sprite(int n, int ch, int col, int r, int c);
void delsprite(int n);
void charset();
void gplvdp(int vect, int adr, int cnt);

// global pointers for all to enjoy - make sure the screen setup code updates them!
// assumptions here are for E/A environment, they may not be accurate and your
// program should NOT trust them
extern unsigned int gImage;			// SIT, Register 2 * 0x400
extern unsigned int gColor;			// CR,  Register 3 * 0x40
extern unsigned int gPattern;		// PDT, Register 4 * 0x800
extern unsigned int gSprite;		// SAL, Register 5 * 0x80
extern unsigned int gSpritePat;		// SDT, Register 6 * 0x800

extern volatile unsigned char gSaveIntCnt;	// console interrupt count byte
