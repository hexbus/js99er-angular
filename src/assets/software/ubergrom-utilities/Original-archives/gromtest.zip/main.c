// TODO: Add testrollover....


// UberGROM test application.
// Get to debug the test app and the GROM at the same time!

#include "vdp.h"

void lockeeprom();
void unlockeeprom();

unsigned char kscan() {
	*((unsigned char *)0x8374) = 0x05;
	__asm__("LWPI >83E0\n\tBL @>000E\n\tLWPI >8300");
	return *((unsigned char*)0x8375);
}

// multiple port GROM access code - this is slow for bulk access
// but will do for this test program, I don't expect that multiple
// reads/writes will be a problem if the cart works at all. ;)
unsigned char GromReadData(unsigned int address, unsigned char port) {
	// we only support 15 ports, this still fits in a char
	port <<= 2;

	// set address
	*((volatile unsigned char*)(0x9c02+port)) = address>>8;
	*((volatile unsigned char*)(0x9c02+port)) = address&0xff;

	// read data
	return *((volatile unsigned char*)(0x9800+port));
}

void GromWriteData(unsigned int address, unsigned char port, unsigned char dat) {
	// we only support 15 ports, this still fits in a char
	port <<= 2;

	// set address
	*((volatile unsigned char*)(0x9c02+port)) = address>>8;
	*((volatile unsigned char*)(0x9c02+port)) = address&0xff;

	// write data
	*((volatile unsigned char*)(0x9C00+port)) = dat;
}

// read and print GPIO till a key is pressed - assumes mapped to 0x6000
void ReadGPIOTillKey() {
	for (;;) {
		unsigned char x = GromReadData(0x6021, 0);		// get input value
		// only the 4 LSb are valid
		if (x&0x01) puts("1"); else puts("0");
		if (x&0x02) puts("1"); else puts("0");
		if (x&0x04) puts("1"); else puts("0");
		if (x&0x08) puts("1\r"); else puts("0\r");
		x=kscan();
		if (x != 0xff) break;
	}
	puts("\n");
}

void hexprint(unsigned char x) {
	char buf[3];

	buf[0]=(x>>4)+'0';
	if (buf[0]>'9') buf[0]+=7;
	buf[1]=(x&0x0f)+'0';
	if (buf[1]>'9') buf[1]+=7;
	buf[2]='\0';
	puts(buf); 
}

void halt() __attribute__ ((noreturn));
void halt() {
	puts("\nEnable bases and wipe EEPROM...\n");
	unlockeeprom();
	GromWriteData(0xf800, 15, 1);	// leave bases and recovery program on
	GromWriteData(0xf801, 15, ~1);
	for (unsigned int idx=0xf802; idx<0xf901; idx++) {	// all bases configuration
		GromWriteData(idx, 15, 0);		// makes it invalid, but not erased, so the chip's startup code doesn't kick in
	}

	puts("\n** DONE **");
	
	// wait for the user to press QUIT
	VDP_INT_ENABLE;
	for (;;) { }
}

const char *TestString="ABCDEFGHIJKLMNOPQRSTUVWXYZ";

void lockeeprom() {
	GromWriteData(0xffff, 15, 0);		// writing non-0x5A to the lock byte ALWAYS locks the EEPROM
}

void unlockeeprom() {
	GromWriteData(0xffff, 15, 0x55);
	GromWriteData(0xffff, 15, 0xaa);
	GromWriteData(0xffff, 15, 0x5a);
}

void addresstest() {
	unsigned char x1,x2,x3;

	// test whether address wrap configuration works
	puts("WARNING: this test will fail if run\n");
	puts("         AFTER the flash test.\n");

	// make sure we have the first GROM config in the expected slots
	unlockeeprom();
		GromWriteData(0xf805, 15, 0x11);	// second bank of GROM to >6000 - AVR studio has a bug that makes linking to 0x0000 hard
		GromWriteData(0xf80D, 15, ~0x11);	// confirm
		GromWriteData(0xf806, 15, 0x12);	// third bank of GROM to >8000
		GromWriteData(0xf80E, 15, ~0x12);	// confirm

		// configure device
		GromWriteData(0xf800, 15, 0x04);	// no bases, recovery on and rollover on
		GromWriteData(0xf801, 15, ~0x04);
	lockeeprom();
	
	// okay, collect the data then try a wrap-over
	x1=GromReadData(0x6000, 0);		// check at the base
	x2=GromReadData(0x8000, 0);		// check the next grom
	if (x1 == x2) {
		// okay, what are the odds? Oh yeah, 1 in 256, if it were random.
		// this message just tells me to change the test ;) 
		puts("* Unable to execute test.\n");
		return;
	}

	puts("Testing address wrap on...");
	GROMWA=0x7f;
	GROMWA=0xff;					// set address of 0x7fff
	__asm__("NOP");					// force a delay
	x3=GROMRD;						// read the byte - don't care what it is
	__asm__("NOP");					// force a delay
	x3=GROMRD;						// now we have something.. which one?
	if (x3 == x1) {
		// it wrapped around, we did NOT want that
		puts("FAILED\n");
	}
	if (x3 != x2) {
		// this should not happen!
		puts("Unexpected Byte!\n");
	} else {
		puts("OK\n");
	}

	// configure device - now turn it off (default mode)
	unlockeeprom();
		GromWriteData(0xf800, 15, 0x00);	// no bases, recovery on and rollover off
		GromWriteData(0xf801, 15, ~0x00);
	lockeeprom();

	// set it up again!
	puts("Testing address wrap off..");
	GROMWA=0x7f;
	GROMWA=0xff;					// set address of 0x7fff
	__asm__("NOP");					// force a delay
	x3=GROMRD;						// read the byte - don't care what it is
	__asm__("NOP");					// force a delay
	x3=GROMRD;						// now we have something.. which one?
	if (x3 == x2) {
		// it did NOT wrap around
		puts("FAILED\n");
		return;
	}
	if (x3 != x1) {
		// this should not happen!
		puts("Unexpected Byte!\n");
	} else {
		puts("OK\n");
	}

}

void eepromtest() {
	//Test read and write EEPROM at >F800 in base 15 (>983C, >983E, >9C3C, >9C3E). 
	// we just try a few addresses here, a full test will come when we map it.
	puts("Testing configuration space...\n");

	// bases enabled or not doesn't matter yet
	{
		puts("Testing EEPROM lock...\n");
		lockeeprom();
		unsigned char x = GromReadData(0xf802, 15);		// we're going to change this anyway
		GromWriteData(0xf802, 15, ~x);		// invert
		if (x != GromReadData(0xf802, 15)) {
			puts("FAIL - not locked!\n");
			return;
		}
		// bad unlock sequence
		GromWriteData(0xffff, 15, 0x55);
		GromWriteData(0xffff, 15, 0xaa);
		GromWriteData(0xf802, 15, ~x);
		GromWriteData(0xffff, 15, 0x5a);
		if (x != GromReadData(0xf802, 15)) {
			puts("FAIL - interrupted unlock!\n");
			return;
		}
		// good unlock sequence
		unlockeeprom();
		GromWriteData(0xf802, 15, ~x);
		if (x == GromReadData(0xf802, 15)) {
			puts("FAIL - did not unlock\n");
			return;
		}
		// rest of the code assumes unlocked
	}

	for (unsigned int idx=0xf802; idx>0xf000; idx+=0x200) {	// comparison handles wraparound
		puts("Testing write...");
		GromWriteData(idx, 15, idx>>8);
		puts("Testing read...");
		unsigned char x=GromReadData(idx, 15);
		if (x==(idx>>8)) {
			puts("OK\n");
		} else {
			puts("FAIL\n");
			puts("At ");
			hexprint(idx>>8);
			hexprint(idx&0xff);
			puts(" wrote ");
			hexprint(idx>>8);
			puts(" read ");
			hexprint(x);
			puts("\n");
			return;
		}
	}

	//Disable bases.
	puts("Disable bases...\n");
	GromWriteData(0xf800, 15, 0);	// leave recovery program on
	GromWriteData(0xf801, 15, ~0);

	//Map EEPROM to >6000 in config:
	puts("Map EEPROM to >6000\n");
	GromWriteData(0xf805, 15, 0x20);
	GromWriteData(0xf80d, 15, ~0x20);

	//-test read of old data
	puts("Testing read of previous data...");
	for (unsigned int idx=0x6002; idx<0x6800; idx+=0x200) {
		unsigned char x=GromReadData(idx, 0);
		if (x==((idx+0x9800)>>8)) {
			puts("OK.");
		} else {
			puts("FAIL\n");
			return;
		}
	}
	puts("\n");

	//-test failure reading 4096
	puts("Testing limits...");
	GromWriteData(0x6000+4095, 0, 0xaa);
	unsigned char x=GromReadData(0x6000+4095, 0);
	if (x == 0xaa) {
		puts("ok.");
	} else {
		puts("FAIL\n");
		return;
	}
	GromWriteData(0x6000+4096, 0, 0x55);
	x=GromReadData(0x6000+4096, 0);
	if (x != 0x55) {
		// probably should check for 0xff, not sure what would return...
		puts("ok.\n");
	} else {
		puts("FAIL\n");
		return;
	}

	//-Test write at each valid address
	puts("Testing full write...");
	for (unsigned int idx=0x2; idx<4096; idx++) {
		// skip configuration area for chip and for 0x6000
		if ((idx == 0x0005) || (idx==0x000d)) continue;
		GromWriteData(0x6000+idx, 0, idx&0xff);
	}
	puts("reading...");
	for (unsigned int idx=0x2; idx<4096; idx++) {
		// skip configuration area for chip and for 0x6000
		if ((idx == 0x0005) || (idx==0x000d)) continue;
		x=GromReadData(0x6000+idx, 0);
		if (x != (idx&0xff)) {
			puts("FAIL\n");
			return;
		}
	}
	puts("OK\n");

	//Map EEPROM to >8000 in config:
	//-verify read back of each value
	puts("Testing EEPROM read at >8000...");
	GromWriteData(0xf806, 15, 0x20);
	GromWriteData(0xf80e, 15, ~0x20);

	// skip all configuration area
	for (unsigned int idx=0x12; idx<4096; idx++) {
		x=GromReadData(0x8000+idx, 0);
		if (x != (idx&0xff)) {
			puts("FAIL\n");
			return;
		}
	}
	puts("OK\n");

	//
	//Map EEPROM to >A000, >C000 and >E000
	//-verify read back at each address
	puts("Testing EEPROM read at >A000...");
	GromWriteData(0xf807, 15, 0x20);
	GromWriteData(0xf80f, 15, ~0x20);

	// skip all configuration area
	for (unsigned int idx=0x12; idx<4096; idx++) {
		x=GromReadData(0xA000+idx, 0);
		if (x != (idx&0xff)) {
			puts("FAIL\n");
			return;
		}
	}
	puts("OK\n");

	puts("Testing EEPROM read at >C000...");
	GromWriteData(0xf808, 15, 0x20);
	GromWriteData(0xf810, 15, ~0x20);

	// skip all configuration area
	for (unsigned int idx=0x12; idx<4096; idx++) {
		x=GromReadData(0xC000+idx, 0);
		if (x != (idx&0xff)) {
			puts("FAIL\n");
			return;
		}
	}
	puts("OK\n");

	puts("Testing EEPROM read at >E000...");
	GromWriteData(0xf809, 15, 0x20);
	GromWriteData(0xf811, 15, ~0x20);

	// skip all configuration area
	for (unsigned int idx=0x12; idx<4096; idx++) {
		x=GromReadData(0xE000+idx, 0);
		if (x != (idx&0xff)) {
			puts("FAIL\n");
			return;
		}
	}
	puts("OK\n");
}

void testram() {
	//Test RAM:
	unlockeeprom();

	//	-enable bases
	puts("Enable bases...\n");
	GromWriteData(0xf800, 15, 1);	// also recovery program
	GromWriteData(0xf801, 15, ~1);

	puts("Testing RAM...\n");
	for (unsigned int base=0; base<16; base+=2) {	// base loop
		puts("Base ");
		hexprint(base);
		for (unsigned int bank=5; bank<10; bank++) {	// bank loop
			puts(".");

			//	-map 8k at each bank
			//	-map 7k block in same bank but next base
			{
				unsigned int bankad = bank+(base<<4);
				GromWriteData(bankad+0xf800, 15, 0x00);		// RAM page 0
				GromWriteData(bankad+8+0xf800, 15, ~0x00);
				GromWriteData(bankad+16+0xf800, 15, 0x01);	// RAM page 1
				GromWriteData(bankad+16+8+0xf800, 15, ~0x01);
			}

			//	-test 8k and 7k by writing an incrementing value (different start)
			unsigned char nStart = (base<<4)+bank;
			unsigned int nBankAd=((bank-5)<<13)+0x6000;
			for (unsigned int nCnt=0; nCnt<8192; nCnt++) {
				GromWriteData(nBankAd+nCnt, base, ((nStart+nCnt)&0xff));
				if (nCnt < 7168) {
					// the end of base 15 is reserved for configuration (so check 14, cause we write base+1)
					if ((base == 14)&&(nBankAd+nCnt>0xf7ff)) continue;
					GromWriteData(nBankAd+nCnt, base+1, (nStart+nCnt+1)&0xff);
				}
			}

			//	-read back and verify
			for (unsigned int nCnt=0; nCnt<8192; nCnt++) {
				unsigned char x;

				x=GromReadData(nBankAd+nCnt, base);
				if (x != ((nStart+nCnt)&0xff)) {
					puts("FAIL - AD:");
					hexprint((nBankAd+nCnt)>>8);
					hexprint((nBankAd+nCnt)&0xff);
					puts(" Base: ");
					hexprint(base);
					puts("\nRead: ");
					hexprint(x);
					puts("  Expected: ");
					hexprint((nStart+nCnt)&0xff);
					return;
				}

				if (nCnt < 7168) {
					// the end of base 15 is reserved for configuration
					if ((base == 14)&&(nBankAd+nCnt>0xf7ff)) continue;

					x=GromReadData(nBankAd+nCnt, base+1);
					if (x != ((nStart+nCnt+1)&0xff)) {
						puts("FAIL2 - AD:");
						hexprint((nBankAd+nCnt)>>8);
						hexprint((nBankAd+nCnt)&0xff);
						puts(" Base: ");
						hexprint(base+1);
						return;
					}
				}
			}

			// unmap
			{
				unsigned int bankad = bank+(base<<4);
				GromWriteData(bankad+0xf800, 15, 0xff);
				GromWriteData(bankad+8+0xf800, 15, 0xff);
				GromWriteData(bankad+16+0xf800, 15, 0xff);
				GromWriteData(bankad+16+8+0xf800, 15, 0xff);
			}
		}
	}
	puts("OK\n");
}

void testgpio() {
	//Test GPIO
	puts("Testing GPIO...");

	unlockeeprom();

	// we don't care if bases are enabled or not here

	GromWriteData(0xf805, 15, 0x30);	// map to 0x6000
	GromWriteData(0xf80D, 15, ~0x30);

	//-Test read all bits (no pull up)
	puts("Input with no PU (key to exit)\n");
	GromWriteData(0x6020, 0, 0x00);		// all input
	GromWriteData(0x6021, 0, 0x00);		// no pull up resistor
	ReadGPIOTillKey();					// call helper function
	while (kscan() != 0xff) { }

	//-Test read all bits with pull up
	puts("Input with PU (key to exit)\n");
	GromWriteData(0x6021, 0, 0x0f);		// pull up resistor active
	ReadGPIOTillKey();					// call helper function
	while (kscan() != 0xff) { }

	//-test write all bits
	puts("Test Output (keys 1-4, or enter)\n");
	GromWriteData(0x6020, 0, 0x0F);		// all output
	GromWriteData(0x6021, 0, 0x00);		// output low
	for (;;) {
		unsigned char x=kscan();
		if (x == 13) break;
		if (x == 49) GromWriteData(0x6021, 0, 0x01);	// 1
		if (x == 50) GromWriteData(0x6021, 0, 0x02);	// 2
		if (x == 51) GromWriteData(0x6021, 0, 0x04);	// 3
		if (x == 52) GromWriteData(0x6021, 0, 0x08);	// 4
		if (x == 0xff) GromWriteData(0x6021, 0, 0x00);	// all off
	}
}

void testadc() {
	//
	//Test ADC
	unlockeeprom();

	// we MUST have bases enabled
	puts("Enable bases...\n");
	GromWriteData(0xf800, 15, 1);	// also recovery program
	GromWriteData(0xf801, 15, ~1);

	puts("Test ADC's 1-4 (space=exit)\n");
	GromWriteData(0xf805, 15, 0x40);	// map to 0x6000, port 0
	GromWriteData(0xf80D, 15, ~0x40);
	GromWriteData(0xf815, 15, 0x41);	// map to 0x6000, port 1
	GromWriteData(0xf81D, 15, ~0x41);
	GromWriteData(0xf825, 15, 0x42);	// map to 0x6000, port 2
	GromWriteData(0xf82D, 15, ~0x42);
	GromWriteData(0xf835, 15, 0x43);	// map to 0x6000, port 3
	GromWriteData(0xf83D, 15, ~0x43);

	//-Test ADC0 reads 0-5V
	//-Test ADC1 reads 0-5V
	//-Test ADC2 reads 0-5v
	//-Test ADC3 reads 0-5v
	for (;;) {
		for (unsigned int idx=0; idx<4; idx++) {
			unsigned char x=GromReadData(0x6020, idx);	// get ADC
			hexprint(x);								// emit it
			puts("   ");
		}
		puts("\r");

		if (kscan() == 32) break;
	}
	puts("\n");
}

void testuart() {
	//Test UART
	unlockeeprom();

	// we don't care about bases here

	puts("Test UART\n");
	GromWriteData(0xf805, 15, 0x50);	// map to 0x6000, port 0
	GromWriteData(0xf80D, 15, ~0x50);
	
	//-Configure 57.6k, no buffering
	GromWriteData(0x6021, 0, 0x23);		// 8N1, no buffers, U2X
	GromWriteData(0x6022, 0, 16);		// 57.6k
	GromWriteData(0x6023, 0, 0);

	//-write a string char-by-char, monitoring config bits
	puts("Press enter when ready to receive 57.6k\n");
	while (kscan() != 13) { }
	{
		const char *p = TestString;
		while (*p) {
			for (;;) {
				unsigned char x = GromReadData(0x6020, 0);
				if (x&0x02) break;
			}
			GromWriteData(0x6100, 0, *p);
			p++;
		}
	}
			
	//-receive several characters, monitoring config bits
	puts("Send a short string, space to quit\n");
	while (kscan() != 32) {
		unsigned char x = GromReadData(0x6020, 0);
		unsigned char out[2] = { 0,0 };

		if (x&0x20) puts("`");	// overrun
		if (x&0x01) {
			out[0]=GromReadData(0x7000, 0);
			puts(out);
		}
	}

	//-Configure 600 bps (deliberately slow)
	GromWriteData(0x6022, 0, 0x82);
	GromWriteData(0x6023, 0, 0x06);
	puts("\nPress enter when ready to receive 600bps\n");
	while (kscan() != 13) { }

	puts("TX buffer has ");
	hexprint(GromReadData(0x6025,0));
	puts(" bytes free\n");

	//-Write a short string without monitoring, wait for it to finish
	{
		const char *p = TestString;
		GromWriteData(0x6100, 0, '\r');
		GromWriteData(0x6100, 0, '\n');
		while (*p) {
			GromWriteData(0x6100, 0, *(p++));
		}
		GromWriteData(0x6100, 0, '\r');
		GromWriteData(0x6100, 0, '\n');

		puts("TX buffer has ");
		hexprint(GromReadData(0x6025,0));
		puts(" bytes now\n");

		for (;;) {
			unsigned char x = GromReadData(0x6020,0);
			if (x&0x04) break;
		}
	}
	puts("Check string.\n");

	puts("Press space for longer string\n");
	while (kscan() != 32) { }

	//-write a long string (>255 bytes) checking the buffer full bit to avoid overrun - make sure no chars drop
	// we need to send the alphabet 9 times to fill the buffer, so we'll send 10 to be sure
	for (int idx=0; idx<10; idx++) {
		const char *p = TestString;
		while (*p) {
			unsigned char x = GromReadData(0x6020, 0);
			if ((x&0x02) == 0) continue;
			GromWriteData(0x6100, 0, *(p++));
		}
	}
	puts("Check string. Then send a short string\n");
	puts("Enter to quit\n");

	unsigned char y=0;
	for (;;) {
		unsigned char x = GromReadData(0x6024,0);
		if (x > y) {
			puts("RX Buffer has ");
			hexprint(x);
			puts(" chars\n");
			y=x;
		}
		if (y >= 5) break;
		if (kscan() == 13) break;
	}

	//-receive a short string
	while (kscan() != 13) {
		unsigned char x = GromReadData(0x6020, 0);
		unsigned char out[2] = { 0,0 };

		if (x&0x20) puts("`");	// overrun
		if (x&0x01) {
			out[0]=GromReadData(0x7000, 0);
			puts(out);
		}
	}

	//-Configure 57.6k
	//-receive a long string - watch bits for overflow warning
	puts("\nSet bps back to 57.6k, then\n");
	puts("Send a string >255 chars\n");
	puts("it should overflow! (`)\n");
	puts("Space to exit.\n");
	GromWriteData(0x6022, 0, 16);		// 57.6k
	GromWriteData(0x6023, 0, 0);

	while (kscan() != 32) {
		unsigned char x = GromReadData(0x6020, 0);
		unsigned char out[2] = { 0,0 };

		if (x&0x20) puts("`");	// overrun
		if (x&0x01) {
			out[0]=GromReadData(0x7000, 0);
			puts(out);
		}
	}
}

void testflash() {
	//Test Flash
	unlockeeprom();

	// we don't care about bases here

	//-Much like RAM, except we have to write a page at a time and map it in to read it back
	//-By this point we can assume that the paging code itself works
	// we need to test ALL the flash, since this is arguably the most important feature
	puts("\nApply Flash WP then press enter\n");	// this just lets us check write protect, user can skip if they want
repeat:
	while (kscan() != 13) { }

	// there are 15 8k blocks, each block is written 512 bytes at a time. We'll write, read as a test
	puts("Testing flash\n");

	for (int page=0; page<15; page++) {
		hexprint(page);
		puts(":");

		GromWriteData(0xf805, 15, 0x60);	// map to 0x6000, port 0, flash device
		GromWriteData(0xf80D, 15, ~0x60);

		// TODO: something is wrong with the compiler? - this seems to be writing to >9C3E and >9C3C instead of >9C00 and >9C02
		GromWriteData(0x6104, 0, page);	// load the page number

		if (GromReadData(0x6103, 0) == 0x02) {
			puts("\nWP found. Remove then press enter.\n");
			while (kscan() == 13) { }
			goto repeat;
		}

		for (int sub=0; sub<32; sub++) {
			GromWriteData(0x6100, 0, sub);
			puts("E");	// erase
			GromWriteData(0x6101, 0, 0x31);
			GromWriteData(0x6102, 0, ~0x31);		// erase
			if (GromReadData(0x6103,0) != 0) {
				puts("Error ");
				hexprint(GromReadData(0x6103,0));
				return;
			}
			puts("F");	// fill
			for (int dat=0; dat<256; dat++) {
				GromWriteData(0x6000+dat, 0, (dat+(page<<4)+sub)&0xff);
			}
			puts("W");	// write
			GromWriteData(0x6101, 0, 0xd2);
			GromWriteData(0x6102, 0, 0x2d);
			
			if (GromReadData(0x6103,0) != 0) {
				puts("Error ");
				hexprint(GromReadData(0x6103,0));
				return;
			}
		}

		puts("R");
		GromWriteData(0xf805, 15, 0x10+page);	// map GROM to 0x6000, port 0
		GromWriteData(0xf80D, 15, ~(0x10+page));
		for (int sub=0; sub<32; sub++) {
			for (int dat=0; dat<256; dat++) {
				int ad=0x6000+dat+(sub<<8);
				int exp=((dat+(page<<4)+sub)&0xff);
				if (exp != GromReadData(ad, 0)) {
					puts("\nFAIL! At ");
					hexprint(ad>>8);
					hexprint(ad&0xff);
					puts(" expected ");
					hexprint(exp);
					puts(" got ");
					hexprint(GromReadData(ad, 0));
					puts("\n");
					return;
				}
			}
		}
		puts("-OK\n");
	}
}

void testtimer() {
	// we don't care about bases here either
	unlockeeprom();

	//Test timer
	puts("Testing timer...\n");
	GromWriteData(0xf805, 15, 0x70);	// map timer to 0x6000, port 0
	GromWriteData(0xf80D, 15, ~0x70);

	//-read 16-bits, make sure it changes sensibly
	{
		unsigned char msb, lsb, fl;
		unsigned char x,y;

		lsb=GromReadData(0x6020, 0);
		msb=GromReadData(0x6021, 0);

		puts("Counting 16 bit...\n");
		fl=0;
		for (unsigned int idx=0; idx<1000; idx++) {
			x = GromReadData(0x6020,0);
			y = GromReadData(0x6021,0);
			if (lsb != x) fl|=1;
			if (msb != y) fl|=2;
			lsb=x;
			msb=y;
			if (fl == 3) break;
		}
		if (fl != 3) {
			puts("FAIL!\n");
			return;
		}

		//-Read LSB only, make sure it changes
		puts("Counting 8 bit...\n");
		fl=0;
		for (unsigned int idx=0; idx<1000; idx++) {
			x = GromReadData(0x6020,0);
			if (lsb != x) fl++;
			lsb=x;
			if (fl > 2) break;
		}
		if (fl < 3) {
			puts("FAIL!\n");
			return;
		}
		
		//-Read MSB only, make sure it latches
		puts("Testing MSB latch...\n");
		fl=0;
		for (unsigned int idx=0; idx<1000; idx++) {
			y = GromReadData(0x6021,0);
			if (msb != y) fl++;
			msb=y;
			if (fl > 2) break;
		}
		if (fl > 2) {
			puts("FAIL!\n");
			return;
		}
	}
}

int main() {
	// init the screen
	{
		int x = set_text();
		charset();
		vdpmemset(gImage, ' ', 960);
		VDP_SET_REGISTER(VDP_REG_MODE1, x);	
		*(volatile unsigned char*)0x83D4 = x;	// must have a copy of VDP Reg 1 if you ever use KSCAN
	}

	unsigned int x = 0;	// which option - overloaded like mad

	for (;;) {
		unlockeeprom();
		puts("Clearing map...\n");
		for (int idx=0xf802; idx<0xf902; idx++) {
			GromWriteData(idx, 15, 0xff);		// nothing everywhere
		}
		lockeeprom();

		if (x&0x8000) {
			x++;	// "next" test
		} else {
			// menu
			puts("\nPRESS:\n0 - All tests\n1 - Address Wrap\n2 - EEPROM\n3 - RAM\n4 - GPIO\n5 - ADC\n6 - UART\n7 - FLASH\n8 - Timer\n9 - Quit\n");
			x=0xff;
			while ((x<'0')||(x>'9')) x=kscan();
			x-='0';
			if (x == 0) x=0x8001;
		}

		switch (x&0xff) {
		case 1: addresstest(); break;
		case 2: eepromtest(); break;
		case 3:	testram(); break;
		case 4: testgpio(); break;
		case 5: testadc(); break;
		case 6: testuart(); break;
		case 7: testflash(); break;
		case 8: testtimer(); break;
		case 9: halt();
		}
	}

	return 0;
}
