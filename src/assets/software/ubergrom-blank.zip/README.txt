Blank UberGROM cartridge template

UberGROM firmware by Mike Brent (Tursi): https://harmlesslion.com
Source: https://github.com/tursilion/ubergrom
Firmware is unchanged. The UberGROM Addendum in Source License.txt permits
release of cartridges using the unmodified firmware with attribution.

Application Flash (120 KiB) and EEPROM (4 KiB) are erased. The final 8 KiB
contains the original firmware, including EASYbug and Run Program File.
js99er initializes erased EEPROM with the firmware's initial mappings.
No parallel ROM, application, GROMCFG or disk is included.
Hold Space during startup to select recovery.

Firmware SHA-256: 3c90c9ddb44eea6415e1e4362b99afe6c6fd601c427177acb2e3bfa325fbabc6
