// VDP code for the TI-99/4A by Tursi
// and a little GROM code too since I need it for the
// character set copy.
// You can copy this file and use it at will if it's useful

#include "vdp.h"

// some text output stuff
int nTextRow,nTextEnd;		// definitions for the bottom line of the screen
int nTextPos;

// if you undef this, the lowercase data is not included and the small capitals will be read
// from GROM in the charset function - saves 250 bytes
//#define USE_TRUE_LOWER_CASE

#ifdef USE_TRUE_LOWER_CASE
const unsigned char TrueLowerCase[] = {				// chars 96-122
	 0x20,0x10,0x08,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x38,0x04,0x3C,0x44,0x3C,0x00,
	 0x40,0x40,0x78,0x44,0x44,0x44,0x78,0x00,0x00,0x00,0x38,0x44,0x40,0x40,0x38,0x00,
	 0x04,0x04,0x3C,0x44,0x44,0x44,0x3C,0x00,0x00,0x00,0x38,0x44,0x7C,0x40,0x38,0x00,
	 0x0C,0x10,0x38,0x10,0x10,0x10,0x10,0x00,0x00,0x00,0x3C,0x44,0x44,0x3C,0x04,0x38,
	 0x40,0x40,0x78,0x44,0x44,0x44,0x44,0x00,0x10,0x00,0x10,0x10,0x10,0x10,0x38,0x00,
	 0x08,0x00,0x08,0x08,0x08,0x08,0x48,0x30,0x40,0x40,0x44,0x48,0x70,0x48,0x44,0x00,
	 0x30,0x10,0x10,0x10,0x10,0x10,0x38,0x00,0x00,0x00,0x68,0x54,0x54,0x54,0x54,0x00,
	 0x00,0x00,0x58,0x64,0x44,0x44,0x44,0x00,0x00,0x00,0x38,0x44,0x44,0x44,0x38,0x00,
	 0x00,0x00,0x78,0x44,0x44,0x44,0x78,0x40,0x00,0x00,0x3C,0x44,0x44,0x44,0x3C,0x04,
	 0x00,0x00,0x28,0x34,0x20,0x20,0x20,0x00,0x00,0x00,0x3C,0x40,0x38,0x04,0x78,0x00,
	 0x00,0x10,0x38,0x10,0x10,0x10,0x0C,0x00,0x00,0x00,0x44,0x44,0x44,0x4C,0x34,0x00,
	 0x00,0x00,0x44,0x44,0x44,0x28,0x10,0x00,0x00,0x00,0x54,0x54,0x54,0x54,0x28,0x00,
	 0x00,0x00,0x44,0x28,0x10,0x28,0x44,0x00,0x00,0x00,0x44,0x44,0x44,0x3C,0x04,0x38,
	 0x00,0x00,0x7C,0x08,0x10,0x20,0x7C,0x00,0x00,0x0C,0x10,0x10,0x20,0x10,0x10,0x0C,
	 0x00,0x10,0x10,0x10,0x00,0x10,0x10,0x10,0x00,0x60,0x10,0x10,0x08,0x10,0x10,0x60,
	 0x00,0x00,0x20,0x54,0x08,0x00,0x00,0x00
};
#endif

// global pointers for all to enjoy - make sure the screen setup code updates them!
// assumptions here are for E/A environment, they may not be accurate and your
// program should NOT trust them
unsigned int gImage = 0x0000;		// SIT, Register 2 * 0x400
unsigned int gColor = 0x0380;		// CR,  Register 3 * 0x40
unsigned int gPattern = 0x0800;		// PDT, Register 4 * 0x800
unsigned int gSprite = 0x0300;		// SAL, Register 5 * 0x80
unsigned int gSpritePat = 0x0000;	// SDT, Register 6 * 0x800

volatile unsigned char gSaveIntCnt;	// console interrupt count byte

// setting up standard screen modes - blanks the screen and returns the unblank command
// interrupts are also disabled. Unblank will re-enable them, too, write it to VDP_REG_MODE1
int set_graphics(int sprite_mode) {
	// this layout is untested but should match editor/assembler's
	int unblank = VDP_MODE1_16K | VDP_MODE1_UNBLANK | VDP_MODE1_INT | sprite_mode;
	VDP_SET_REGISTER(VDP_REG_MODE0, 0);
	VDP_SET_REGISTER(VDP_REG_MODE1, VDP_MODE1_16K);		// no need to OR in the sprite mode for now
	VDP_SET_REGISTER(VDP_REG_SIT, 0x00);	gImage = 0x000;
	VDP_SET_REGISTER(VDP_REG_CT, 0x0e);		gColor = 0x380;
	VDP_SET_REGISTER(VDP_REG_PDT, 0x01);	gPattern = 0x800;
	VDP_SET_REGISTER(VDP_REG_SAL, 0x06);	gSprite = 0x300;	vdpchar(gSprite, 0xd0);
	VDP_SET_REGISTER(VDP_REG_SDT, 0x01);	gSpritePat = 0x800;
	nTextRow = 736;
	nTextEnd = 767;
	nTextPos = nTextRow;
	return unblank;
}
int set_text() {
	// this layout is untested but based on tested code
	int unblank = VDP_MODE1_16K | VDP_MODE1_UNBLANK | VDP_MODE1_TEXT | VDP_MODE1_INT;
	VDP_SET_REGISTER(VDP_REG_MODE0, 0);
	VDP_SET_REGISTER(VDP_REG_MODE1, VDP_MODE1_16K | VDP_MODE1_TEXT);
	VDP_SET_REGISTER(VDP_REG_SIT, 0x00);	gImage = 0x000;
	VDP_SET_REGISTER(VDP_REG_PDT, 0x01);	gPattern = 0x800;
	// no sprites and no color in text mode anyway
	nTextRow = 920;
	nTextEnd = 959;
	nTextPos = nTextRow;
	return unblank;
}
int set_multicolor(int sprite_mode) {
	// this layout is untested
	int unblank = VDP_MODE1_16K | VDP_MODE1_UNBLANK | VDP_MODE1_MULTI | VDP_MODE1_INT | sprite_mode;
	VDP_SET_REGISTER(VDP_REG_MODE0, 0);
	VDP_SET_REGISTER(VDP_REG_MODE1, VDP_MODE1_16K | VDP_MODE1_MULTI);		// no need to OR in the sprite mode for now
	VDP_SET_REGISTER(VDP_REG_SIT, 0x00);	gImage = 0x000;
	VDP_SET_REGISTER(VDP_REG_PDT, 0x01);	gPattern = 0x800;
	VDP_SET_REGISTER(VDP_REG_SAL, 0x36);	gSprite = 0x1B00;	vdpchar(gSprite, 0xd0);
	VDP_SET_REGISTER(VDP_REG_SDT, 0x04);	gSpritePat = 0x2000;
	// no color table, it's all in the PDT
	nTextRow = 736;
	nTextEnd = 767;
	nTextPos = nTextRow;
	return unblank;
}

int set_bitmap(int sprite_mode) {
	// note: no masking, full size bitmap mode
	int unblank = VDP_MODE1_16K | VDP_MODE1_UNBLANK | VDP_MODE1_INT | sprite_mode;
	VDP_SET_REGISTER(VDP_REG_MODE0, VDP_MODE0_BITMAP);
	VDP_SET_REGISTER(VDP_REG_MODE1, VDP_MODE1_16K);		// no need to OR in the sprite mode for now
	VDP_SET_REGISTER(VDP_REG_SIT, 0x06);	gImage = 0x1800;
	VDP_SET_REGISTER(VDP_REG_CT, 0xFF);		gColor = 0x2000;
	VDP_SET_REGISTER(VDP_REG_PDT, 0x03);	gPattern = 0x0000;
	VDP_SET_REGISTER(VDP_REG_SAL, 0x36);	gSprite = 0x1B00;	vdpchar(gSprite, 0xd0);
	VDP_SET_REGISTER(VDP_REG_SDT, 0x03);	gSpritePat = 0x1800;
	nTextRow = 736;
	nTextEnd = 767;
	nTextPos = nTextRow;
	return unblank;
}

// Some lower level VDP functions
void writestring(int row, int col, char *pStr) {
	VDP_SET_ADDRESS_WRITE(gImage+(row<<5)+col);
	while (*pStr) {
		VDPWD = *(pStr++);
	}
}

void vdpmemset(int pAddr, int ch, int cnt) {
	VDP_SET_ADDRESS_WRITE(pAddr);
	while (cnt--) {
		VDPWD = ch;
	}
}

void vdpmemcpy(int pAddr, const unsigned char *pSrc, int cnt) {
	VDP_SET_ADDRESS_WRITE(pAddr);
	while (cnt--) {
		VDPWD=*(pSrc++);
	}
}

void vdpmemread(int pAddr, unsigned char *pDest, int cnt) {
	VDP_SET_ADDRESS(pAddr);
	while (cnt--) {
		*(pDest++)=VDPRD;
	}
}

// this one writes an incrementing series of bytes
// normally you'd use this to set up bitmap or multicolor
void vdpwriteinc(int pAddr, int nStart, int cnt) {
	VDP_SET_ADDRESS_WRITE(pAddr);
	while (cnt--) {
		VDPWD=nStart++;
	}
}
void vdpchar(int pAddr, int ch) {
	VDP_SET_ADDRESS_WRITE(pAddr);
	VDPWD=ch;
}

void vdpwritescreeninc(int pAddr, int nStart, int cnt) {
	VDP_SET_ADDRESS_WRITE(pAddr+gImage);
	while (cnt--) {
		VDPWD=nStart++;
	}
}
void vdpscreenchar(int pAddr, int ch) {
	VDP_SET_ADDRESS_WRITE(pAddr+gImage);
	VDPWD=ch;
}


void vdpwaitvint() {
	// wait for a vertical interrupt to occur (enables interrupts - first call may not wait)
	VDP_INT_ENABLE; 
	while (VDP_INT_COUNTER == gSaveIntCnt) { } 
	gSaveIntCnt=VDP_INT_COUNTER; 
	VDP_INT_DISABLE; 
}

// some TI like functions
void hchar(int r, int c, int ch, int cnt) {
	vdpmemset(gImage+(r<<5)+c, ch, cnt);
}
void vchar(int r, int c, int ch, int cnt) {
	int pAddr = gImage+(r<<5)+c;
	while (cnt--) {
		vdpchar(pAddr, ch);
		pAddr+=32;
	}
}
unsigned char gchar(int r, int c) {
	VDP_SET_ADDRESS(gImage+(r<<5)+c);
	return VDPRD;
}

void sprite(int n, int ch, int col, int r, int c) {
	unsigned int adr=gSprite+(n<<2);
	VDP_SET_ADDRESS_WRITE(adr);
	VDPWD=r;
	VDPWD=c;
	VDPWD=ch;
	VDPWD=col;
}

// just pushes it off screen, but not disabled
void delsprite(int n) {
	unsigned int adr=gSprite+(n<<2);
	VDP_SET_ADDRESS_WRITE(adr);
	VDPWD=192;
}

void scrn_scroll() {
	// hacky, slow, but functional scroll that takes minimal memory
	unsigned char x[4];		// 4 byte buffer to speed it up
	int nLine = nTextEnd-nTextRow+1;
	for (int adr=nLine+gImage; adr<nTextEnd; adr+=4) {
		vdpmemread(adr, x, 4);
		vdpmemcpy(adr-nLine, x, 4);
	}
	vdpmemset(nTextRow, ' ', nLine);	// clear the last line
}

// some text output code (printable characters only)
// with very limited formatting, \r, \n
void puts(char *s) {
	while (*s) {
		unsigned char tmp = *s;
		switch (tmp) {
		case '\r':
			nTextPos = nTextRow;
			break;

		case '\n':
			scrn_scroll();
			nTextPos = nTextRow;
			break;

		default:
			if ((tmp < 32) || (tmp >= 127)) tmp='.';
			vdpchar(nTextPos, tmp);
			nTextPos++;
			if (nTextPos > nTextEnd) {
				scrn_scroll();
				nTextPos = nTextRow;
			}
			break;
		}
		s++;
	}
}

// load the character set including lowercase from the GROMs (assumes a TI GROM is in place!)
// these will not work on the 99/4 or likely the 99/8

// Copy cnt characters from a GPL copy function vectored at
// vect to VDP adr. GPL vector must be a B or BR and
// the first actual instruction must be a DEST with an
// immediate operand. 994A only (99/4 uses 6 byte chars)
void gplvdp(int vect, int adr, int cnt) {
	GROM_SET_ADDRESS(vect);
	vect=(GROMRD<<8);		// get pointed to vector address
	vect|=GROMRD;			// must be two lines, because otherwise order is not guaranteed!

	vect &= 0x1fff;			// mask out instruction
	vect+=3;				// skip instruction and destination bytes

	GROM_SET_ADDRESS(vect);	// set new GROM address
	vect=(GROMRD<<8);		// get actual address of the table
	vect|=GROMRD;			// must be two lines, because otherwise order is not guaranteed!
	GROM_SET_ADDRESS(vect);	// and set that GROM address - GROM is now ready!

	VDP_SET_ADDRESS_WRITE(adr);	// VDP is now ready!

	while (cnt--) {
		VDPWD = 0;			// pad the top of the char with a space
		for (int idx=0; idx<7; idx++) {		// then copy 7 bytes
			VDPWD = GROMRD;	// copy a byte (both sides autoincrement)
		}
	}
}

void charset() {
#ifdef USE_TRUE_LOWER_CASE
	vdpmemcpy(gPattern+0x300, TrueLowerCase, sizeof(TrueLowerCase));
	gplvdp(0x0018, gPattern+0x100-1, 64);	// the rest of the character set (-1 to shift it up to match lowercase)
#else
	gplvdp(0x004a, gPattern+0x300, 31);	// lower case letters
	gplvdp(0x0018, gPattern+0x100, 64);	// the rest of the character set (not shifted)
#endif
}


